package com.example.giuaky

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class ActivityInformation : AppCompatActivity() {
    lateinit var textview1: TextView
    lateinit var textview2: TextView
    lateinit var textview3: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_information)
        textview1 = findViewById(R.id.textView)
        textview2 = findViewById(R.id.textView2)
        textview3 = findViewById(R.id.textView3)
        val intent2 = intent
        val string1 = intent2.getStringExtra("data1")
        val string2 = intent2.getStringExtra("data2")
        val string3 = intent2.getStringExtra("data3")
        textview1.text = string1
        textview2.text = string2
        textview3.text = string3
    }
}